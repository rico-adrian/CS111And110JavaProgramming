File    : README.txt
Author  : Rico H Adrian
Project : CS111 Final project
Date    : 26 July 2016


Explanation: This program displays the GUI of a dice-rolling game, with 2 players. Each players roll 2 dices.
The one with a higher total score wins the game. There are 4 pictures of dices. each dices start with side 1.
The dices sides will change based on the rolls.


How to run the program : After the file DiceRoll.java has been compiled, press the rolls button (there are 4 buttons) 
to get a random result of the dices. Press the "Display Winner" button to display the winner of the game. The "Reset"
button is to reset the game (kind of a "play again" button) and the "quit" button is to exit the game.


Known bugs: There are no bugs in the program. 