//import statements
import java.util.*;
import javax.swing.*;
import java.awt.event.*; 
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.awt.*;
import java.io.*;


public class DiceRoll extends JFrame {
   
   //fields
   private JPanel panel;
   private JButton player1TotalScore;
   private JButton player2TotalScore;
   private JButton winner;
   private JTextField displayPlayer1Result;
   private JTextField displayPlayer2Result;
   private JTextField displayWinner;
   private final int WINDOW_WIDTH = 500, WINDOW_HEIGHT = 600;
   private JLabel pictureOfDice;
   
   
   //constructor
   //building and adding panel inside it
   //and set things such as title and window size
   public DiceRoll() {
      buildPanel();
      add(panel);
      setTitle("Dice Roller Competition");
      setSize(WINDOW_WIDTH, WINDOW_HEIGHT);
      setVisible(true);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setLayout(new BorderLayout()); 
   }
   
   //build panel method
   private void buildPanel() {
      try {
         //set the textField and button fields
         player1TotalScore        = new JButton("Player 1 Total Score");
         player2TotalScore        = new JButton("Player 2 Total Score");
         winner                   = new JButton("Winner");
         displayPlayer1Result     = new JTextField(10);
         displayPlayer2Result     = new JTextField(10);
         displayWinner            = new JTextField(10);
         BufferedImage myPicture  = ImageIO.read(new File("Dice.jpg"));
         JLabel pictureOfDice     = new JLabel(new ImageIcon(myPicture));
         player1TotalScore.addActionListener(new CalcButtonListener());
         player2TotalScore.addActionListener(new CalcButtonListener());
         winner.addActionListener(new CalcButtonListener());
         //adding all the fields into panel
         panel = new JPanel();
         panel.add(player1TotalScore);
         panel.add(displayPlayer1Result);
         panel.add(player2TotalScore);
         panel.add(displayPlayer2Result);
         panel.add(winner);
         panel.add(displayWinner);
         panel.add(pictureOfDice); 
      }
      
      catch (IOException e) {
         System.out.println("Image is not found");
         System.out.println(e.getMessage());
      }        


   }
   
   //listener method to calculate output
   private class CalcButtonListener implements ActionListener {
      double output;
      
      public void actionPerformed(ActionEvent e) {
         
       
     
      
      }

   }

   
   //main class
   public static void main(String[] args)throws IOException {
      DiceRoll diceRoll=new DiceRoll();
    
   
   }
   
   
   
} 